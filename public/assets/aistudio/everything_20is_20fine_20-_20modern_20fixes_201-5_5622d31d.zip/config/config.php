<?php
/**
 * نسخه نمونه پیکربندی اصلی سامانه منوی دیجیتال کافه
 * توسعه داده شده برای پایداری و امنیت بالا بر روی هاست اشتراکی cPanel
 * 
 * راهنما: این فایل را به config.php تغییر نام داده و اطلاعات دیتابیس خود را وارد کنید.
 */

// یکسان‌سازی تاریخ و ساعت برنامه با منطقه زمانی ایران
date_default_timezone_set('Asia/Tehran');

// شروع امن نشست (Session)
if (session_status() === PHP_SESSION_NONE) {
    // افزایش امنیت کوکی‌های نشست
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        ini_set('session.cookie_secure', 1);
    }
    session_start();
}

// تنظیمات اتصال به دیتابیس MySQL
define('DB_HOST', 'localhost');
define('DB_NAME', 'h398742_cafe'); // نام دیتابیس ساخته شده در cPanel
define('DB_USER', 'h398742_cafe'); // نام کاربری دیتابیس ساخته شده در cPanel
define('DB_PASS', '@NIA#1400'); // رمز عبور دیتابیس ساخته شده در cPanel

// تنظیمات کلی سیستم
define('CURRENCY', 'تومان');
define('ADMIN_MAX_ATTEMPTS', 5); // حداکثر دفعات تلاش ناموفق برای ورود ادمین
define('ADMIN_LOCKOUT_TIME', 900); // زمان مسدود شدن ادمین (۱۵ دقیقه به ثانیه)

// وارد کردن کتابخانه تقویم جلالی
require_once __DIR__ . '/../functions/jdf.php';

// برقراری ارتباط با دیتابیس با استفاده از PDO
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+03:30'",
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // در صورتی که دیتابیس هنوز ساخته نشده باشد یا ارور بدهد، سیستم به کاربری عادی لطمه نمی‌زند
    // جهت راحتی خریدار در بارگذاری اولیه در سی‌پنل، ارور به صورت مناسب هندل می‌شود
    $pdo = null;
}

/**
 * جلوگیری از حملات XSS با پاکسازی خروجی‌ها
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * تولید کد سفارش منحصر به فرد
 */
function generateOrderCode() {
    $jalali_year = JalaliDate::now('Y');
    $rand = str_pad(rand(1000, 9999), 4, '0', STR_PAD_LEFT);
    return "CAFE-" . $jalali_year . "-" . $rand;
}

/**
 * مدیریت توکن امنیتی CSRF جهت جلوگیری از حملات جعل درخواست
 */
function getCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * ثبت فعالیت‌های مدیران در پایگاه داده
 */
function logActivity($action) {
    global $pdo;
    if (!$pdo) return;
    
    $admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;
    $username = isset($_SESSION['admin_user']) ? $_SESSION['admin_user'] : 'unknown';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (admin_id, username, action, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$admin_id, $username, $action, $ip]);
    } catch (Exception $e) {
        // خطا نادیده گرفته می‌شود تا اجرای برنامه اصلی متوقف نگردد
    }
}

/**
 * لود کردن تنظیمات سایت از دیتابیس با قابلیت لود مقادیر پیش‌فرض
 */
function getSettings() {
    global $pdo;
    $default_settings = [
        'cafe_name' => 'کافه گالری',
        'cafe_description' => 'فضایی آرام و دلنشین همراه با بهترین طعم‌های قهوه تخصصی و دسرهای دست‌ساز',
        'cafe_phone' => '021-88888888',
        'cafe_address' => 'تهران، خیابان ولیعصر، نرسیده به میدان ونک، بن‌بست کافه، پلاک ۱۲',
        'working_hours' => 'همه‌روزه از ساعت ۸:۰۰ صبح الی ۲۳:۳۰ شب',
        'primary_color' => '#c49b63',
        'secondary_color' => '#b28b58',
        'instagram_link' => 'https://instagram.com/cafegallery',
        'telegram_link' => 'https://t.me/cafegallery',
        'logo_url' => '',
        'banner_url' => '',
        'webhook_enabled' => '0',
        'webhook_order_url' => '',
        'webhook_secret' => ''
    ];

    if (!$pdo) {
        return $default_settings;
    }

    try {
        $stmt = $pdo->query("SELECT key_name, key_value FROM settings");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        return array_merge($default_settings, $results);
    } catch (Exception $e) {
        return $default_settings;
    }
}

/**
 * ارسال سفارش ثبت‌شده به وب‌هوک تنظیم‌شده؛ خطا نباید ثبت سفارش را مختل کند.
 */
if (!function_exists('dispatchOrderWebhook')) {
    function dispatchOrderWebhook($payload) {
        $settings = getSettings();
        if (($settings['webhook_enabled'] ?? '0') !== '1') return false;
        $url = trim((string)($settings['webhook_order_url'] ?? ''));
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            error_log('[Cafe webhook] URL نامعتبر یا تنظیم نشده است.');
            return false;
        }
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, ['https', 'http'], true) || !function_exists('curl_init')) {
            error_log('[Cafe webhook] پروتکل مقصد یا افزونه cURL در دسترس نیست.');
            return false;
        }
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            error_log('[Cafe webhook] تبدیل payload به JSON ناموفق بود.');
            return false;
        }
        $headers = ['Content-Type: application/json; charset=utf-8', 'Accept: application/json'];
        $secret = (string)($settings['webhook_secret'] ?? '');
        if ($secret !== '') $headers[] = 'X-Webhook-Signature: sha256=' . hash_hmac('sha256', $json, $secret);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json, CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 6,
            CURLOPT_FOLLOWLOCATION => false, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2
        ]);
        $response = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false || $status < 200 || $status >= 300) {
            error_log('[Cafe webhook] ارسال ناموفق بود؛ HTTP ' . $status . ($error !== '' ? '؛ ' . $error : ''));
            return false;
        }
        return true;
    }
}

// لود کردن تمامی تنظیمات سیستم
$settings = getSettings();
