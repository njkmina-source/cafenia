<?php
/**
 * Real sales chart data from the orders table.
 */
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!$pdo) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'اتصال دیتابیس برقرار نیست'], JSON_UNESCAPED_UNICODE);
    exit;
}

$period = $_GET['period'] ?? 'day';
if (!in_array($period, ['day', 'week', 'month'], true)) $period = 'day';

try {
    if ($period === 'day') {
        $tz = new DateTimeZone('Asia/Tehran');
        $dayStart = new DateTimeImmutable('today 06:00:00', $tz);
        $dayEnd = $dayStart->modify('+18 hours');
        $stmt = $pdo->prepare("SELECT (HOUR(created_at) DIV 2) AS bucket, COALESCE(SUM(total_amount), 0) AS amount
                               FROM orders
                               WHERE created_at >= ? AND created_at < ?
                                 AND HOUR(created_at) >= 6 AND status <> 'cancelled'
                               GROUP BY (HOUR(created_at) DIV 2) ORDER BY bucket ASC");
        $stmt->execute([$dayStart->format('Y-m-d H:i:s'), $dayEnd->format('Y-m-d H:i:s')]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($rows as $row) $map[(int)$row['bucket']] = (float)$row['amount'];
        $labels = $values = [];
        for ($hour = 6; $hour < 24; $hour += 2) {
            $labels[] = sprintf('%02d-%02d', $hour, $hour + 2);
            $values[] = $map[(int)($hour / 2)] ?? 0;
        }
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ? AND HOUR(created_at) >= 6 AND status <> 'cancelled'");
        $countStmt->execute([$dayStart->format('Y-m-d H:i:s'), $dayEnd->format('Y-m-d H:i:s')]);
        $orderCount = (int)$countStmt->fetchColumn();
    } else {
        $days = $period === 'week' ? 7 : 30;
        $stmt = $pdo->query("SELECT DATE(created_at) AS bucket, COALESCE(SUM(total_amount), 0) AS amount
                             FROM orders
                             WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL " . ($days - 1) . " DAY)
                               AND created_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
                               AND status <> 'cancelled'
                             GROUP BY DATE(created_at) ORDER BY bucket ASC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($rows as $row) $map[$row['bucket']] = (float)$row['amount'];
        $labels = $values = [];
        $start = (new DateTimeImmutable('today'))->modify('-' . ($days - 1) . ' days');
        for ($i = 0; $i < $days; $i++) {
            $slot = $start->modify("+$i days");
            $labels[] = $slot->format('m/d');
            $values[] = $map[$slot->format('Y-m-d')] ?? 0;
        }
        $countSql = "SELECT COUNT(*) FROM orders WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL " . ($days - 1) . " DAY)
                     AND created_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY) AND status <> 'cancelled'";
    }
    if ($period !== 'day') $orderCount = (int)$pdo->query($countSql)->fetchColumn();
    echo json_encode([
        'success' => true, 'period' => $period, 'labels' => $labels, 'values' => $values,
        'total' => array_sum($values), 'order_count' => $orderCount
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطا در خواندن آمار فروش'], JSON_UNESCAPED_UNICODE);
}
