<?php
/** اعلان سفارش‌های واقعی جدید برای تمام صفحات پنل */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/../../config/config.php';
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401); echo json_encode(['success'=>false,'latest_id'=>0,'orders'=>[]]); exit;
}
if (!$pdo) { http_response_code(503); echo json_encode(['success'=>false,'latest_id'=>0,'orders'=>[]]); exit; }
try {
    $latestId = (int)$pdo->query('SELECT COALESCE(MAX(id), 0) FROM orders')->fetchColumn();
    $afterId = isset($_GET['after_id']) ? max(0, (int)$_GET['after_id']) : null;
    $orders = [];
    $responseLatestId = $latestId;
    // درخواست اول فقط وضعیت موجود را ثبت می‌کند؛ سفارش‌های قدیمی اعلان نمی‌شوند.
    if ($afterId !== null && $latestId > $afterId) {
        $stmt = $pdo->prepare("SELECT id, order_code, customer_name, total_amount, status, created_jalali FROM orders WHERE id > ? ORDER BY id ASC LIMIT 50");
        $stmt->execute([$afterId]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($orders) >= 50) $responseLatestId = (int)end($orders)['id'];
    }
    echo json_encode(['success'=>true,'latest_id'=>$responseLatestId,'orders'=>$orders], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(503); echo json_encode(['success'=>false,'latest_id'=>0,'orders'=>[]], JSON_UNESCAPED_UNICODE);
}
