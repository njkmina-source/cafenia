<!-- اعلان‌های سراسری سفارش جدید -->
<div id="globalOrderToast" role="status" aria-live="polite" class="hidden fixed bottom-4 left-4 z-[100] max-w-sm rounded-2xl border border-[#c49b63]/40 bg-[#171512] p-4 text-stone-100 shadow-2xl">
  <div class="flex items-start gap-3"><div class="rounded-xl bg-[#c49b63]/15 p-2 text-[#c49b63]"><i data-lucide="bell-ring" class="h-5 w-5"></i></div><div class="min-w-0 flex-1"><p class="font-black text-sm">سفارش جدید ثبت شد</p><p id="globalOrderToastText" class="mt-1 text-xs text-stone-300"></p><button type="button" id="enableDesktopNotifications" class="mt-2 hidden rounded-lg border border-white/10 px-2 py-1 text-[10px] text-stone-300 hover:text-white">فعال‌سازی اعلان دسکتاپ</button><a href="orders.php" class="mt-2 inline-block text-xs font-bold text-[#c49b63] underline">مشاهده سفارش‌ها</a></div><button type="button" id="globalOrderToastClose" class="text-stone-400 hover:text-white" aria-label="بستن">×</button></div>
</div>
<div id="desktopNotificationControl" class="hidden"></div>
<audio id="globalOrderAlarm" preload="auto" src="https://assets.mixkit.co/active_storage/sfx/2869/2869-84.wav"></audio>
<script>
(function () {
  const endpoint = 'api/order_notifications.php';
  let latestId = null;
  let busy = false;
  const toast = document.getElementById('globalOrderToast');
  const toastText = document.getElementById('globalOrderToastText');
  const close = document.getElementById('globalOrderToastClose');
  if (close) close.addEventListener('click', () => toast.classList.add('hidden'));
  const desktopButton = document.getElementById('enableDesktopNotifications');
  if (desktopButton && 'Notification' in window && Notification.permission === 'default') {
    desktopButton.classList.remove('hidden');
    desktopButton.addEventListener('click', async () => {
      try { const permission = await Notification.requestPermission(); if (permission === 'granted') desktopButton.textContent = 'اعلان دسکتاپ فعال شد'; else desktopButton.textContent = 'اجازه اعلان داده نشد'; } catch (_) {}
    });
  }
  if (desktopButton && 'Notification' in window && Notification.permission === 'granted') desktopButton.classList.add('hidden');

  function showOrder(order) {
    const text = `${order.order_code || 'سفارش جدید'} · ${order.customer_name || 'مشتری'} · ${Number(order.total_amount || 0).toLocaleString('fa-IR')} تومان`;
    if (toastText) toastText.textContent = text;
    if (toast) toast.classList.remove('hidden');
    // داشبورد خودش صدای سفارش را پخش می‌کند؛ برای جلوگیری از صدای تکراری در آن صفحه، اینجا صدا فقط در صفحات دیگر پخش می‌شود.
    if (!document.getElementById('liveOrdersContainer')) {
      const audio = document.getElementById('globalOrderAlarm');
      if (audio) audio.play().catch(() => {});
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification('سفارش جدید کافه', { body: text, tag: `order-${order.id}` }); } catch (_) {}
    }
  }

  async function poll() {
    if (busy) return;
    busy = true;
    try {
      const url = endpoint + (latestId === null ? '' : `?after_id=${encodeURIComponent(latestId)}`);
      const response = await fetch(url, { cache: 'no-store', credentials: 'same-origin' });
      if (!response.ok) return;
      const data = await response.json();
      if (!data || !data.success) return;
      if (latestId === null) { latestId = Number(data.latest_id || 0); return; }
      const newOrders = Array.isArray(data.orders) ? data.orders : [];
      newOrders.forEach(order => showOrder(order));
      latestId = Math.max(latestId, Number(data.latest_id || 0));
    } catch (_) {
      // خطای موقت شبکه نباید باعث ساخت سفارش یا اعلان جعلی شود.
    } finally { busy = false; }
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) window.lucide.createIcons();
    poll(); setInterval(poll, 5000);
  });
})();
</script>
